"""
What is the most interesting/funny/cool thing(s) about Python that you learned from this class or from somewhere else.

You can use code or a short paragraph to illustrate it.
"""

print('I think the most interesting, fun, relevant, and useful party of this Python class was the portion focused on text mining. I really enjoyed this because we could pull text from online books that I like to read, just like Pride and Prejudice, one of my all-time favorites! Learning this allowed me to understand applications of Python in analyzing a text. I struggled with the text mining assignment, but I did have to do research on sites like stack overflow to help, which taught me a lot about problem solving and not going straight to the professor when I struggled. I think that is what Professor Li taught me best, is to be okay with struggling sometimes. I think this will be very transferable to my job after Babson when I graduate in a few weeks, because I will be working in a company whose entire product is built using Python. I will be able to transfer my skills of understanding how to use Python into that job, and for a business person I believe that is very important to know how to do. ')